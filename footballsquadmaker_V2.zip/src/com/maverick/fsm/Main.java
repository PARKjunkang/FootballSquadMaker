package com.maverick.fsm;

import java.sql.SQLException;
import java.util.Scanner;

import com.maverick.display.Disp;

public class Main {
	private static final Scanner scanner = new Scanner(System.in);
	private static final PlayerManager playerManager = new PlayerManager();
	private static final SquadManager squadManager = new SquadManager();

	public static void main(String[] args) {
		while (true) {
			Disp.title();
			System.out.println("1. Add Player");
			System.out.println("2. List Players");
			System.out.println("3. Create Squad");
			System.out.println("4. List Squads");
			System.out.println("5. Add Player to Squad");
			System.out.println("6. Show Squad Details");
			System.out.println("7. Exit");
			System.out.print("Choose an option: ");

			int option = scanner.nextInt();
			scanner.nextLine(); // Consume newline

			try {
				switch (option) {
				case 1:
					addPlayer();
					break;
				case 2:
					listPlayers();
					break;
				case 3:
					createSquad();
					break;
				case 4:
					listSquads();
					break;
				case 5:
					addPlayerToSquad();
					break;
				case 6:
					showSquadDetails();
					break;
				case 7:
					System.out.println("Exiting...");
					return;
				default:
					System.out.println("Invalid option. Try again.");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	private static void addPlayer() throws SQLException {
		System.out.print("Enter player name: ");
		String name = scanner.nextLine();
		System.out.print("Enter player position (Goalkeeper/Defender/Midfielder/Forward): ");
		String position = scanner.nextLine();
		System.out.print("Enter player skill level: ");
		int skillLevel = scanner.nextInt();
		scanner.nextLine(); // Consume newline

		playerManager.addPlayer(name, position, skillLevel);
		System.out.println("Player added successfully.");
	}

	private static void listPlayers() throws SQLException {
		playerManager.listPlayers();
	}

	private static void createSquad() throws SQLException {
		System.out.print("Enter squad name: ");
		String squadName = scanner.nextLine();

		squadManager.createSquad(squadName);
		System.out.println("Squad created successfully.");
	}

	private static void listSquads() throws SQLException {
		squadManager.listSquads();
	}

	private static void addPlayerToSquad() throws SQLException {
		System.out.print("Enter squad ID: ");
		int squadId = scanner.nextInt();
		System.out.print("Enter player ID: ");
		int playerId = scanner.nextInt();
		System.out.print("Enter player position in squad (Goalkeeper/Defender/Midfielder/Forward): ");
		scanner.nextLine(); // Consume newline
		String position = scanner.nextLine();

		squadManager.addPlayerToSquad(squadId, playerId, position);
		System.out.println("Player added to squad successfully.");
	}

	private static void showSquadDetails() throws SQLException {
		System.out.print("Enter squad ID to view details: ");
		int squadId = scanner.nextInt();

		squadManager.showSquadDetails(squadId);
	}
}

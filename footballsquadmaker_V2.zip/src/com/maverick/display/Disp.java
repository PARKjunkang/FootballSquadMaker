package com.maverick.display;

import com.maverick.util.Cw;

public class Disp {
	static private String TITLE = "football squad maker";
	static private String FEAT = " jk.park";

	public static void title() {

		Cw.w(TITLE);
		Cw.w(FEAT);
		Cw.wn();
	}
}
package com.maverick.fsm;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SquadManager {
	public void createSquad(String squadName) throws SQLException {
		String sql = "INSERT INTO squads (squad_name) VALUES (?)";
		try (Connection conn = DatabaseConnector.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1, squadName);
			stmt.executeUpdate();
		}
	}

	public void addPlayerToSquad(int squadId, int playerId, String position) throws SQLException {
		String sql = "INSERT INTO squad_players (squad_id, player_id, position) VALUES (?, ?, ?)";
		try (Connection conn = DatabaseConnector.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setInt(1, squadId);
			stmt.setInt(2, playerId);
			stmt.setString(3, position);
			stmt.executeUpdate();
		}
	}

	public void listSquads() throws SQLException {
		String sql = "SELECT * FROM squads";
		try (Connection conn = DatabaseConnector.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				var rs = stmt.executeQuery()) {

			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("squad_name");
				System.out.printf("ID: %d, Squad Name: %s%n", id, name);
			}
		}
	}
}

package com.maverick.fsm;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PlayerManager {
	public void addPlayer(String name, String position, int skillLevel) throws SQLException {
		String sql = "INSERT INTO players (name, position, skill_level) VALUES (?, ?, ?)";
		try (Connection conn = DatabaseConnector.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1, name);
			stmt.setString(2, position);
			stmt.setInt(3, skillLevel);
			stmt.executeUpdate();
		}
	}

	public void listPlayers() throws SQLException {
		String sql = "SELECT * FROM players";
		try (Connection conn = DatabaseConnector.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				var rs = stmt.executeQuery()) {

			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String position = rs.getString("position");
				int skillLevel = rs.getInt("skill_level");
				System.out.printf("ID: %d, Name: %s, Position: %s, Skill Level: %d%n", id, name, position, skillLevel);
			}
		}
	}
}
